<!DOCTYPE html>
<html lang="en-US">


<!-- Mirrored from theme.dsngrid.com/droow/one-page-4.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 18 Feb 2023 17:31:01 GMT -->
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title><?php echo e($setting->meta_title); ?></title>
	<meta name="description" content="<?php echo e($setting->meta_description); ?>">
	<meta name="keywords" content="<?php echo e($setting->meta_keywords); ?>">

    <!-- Font Google -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700,800&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,600,700&amp;display=swap" rel="stylesheet">

    <!--Favicon-->
	<link rel="icon" type="image/png" href="<?php echo e(url('storage/'.$setting->favicon)); ?>">
    <!-- custom styles (optional) -->
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.css"
    />
    <link href="<?php echo e(url('assets/css/plugins.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(url('assets/css/style.css')); ?>" rel="stylesheet" />
</head>

<body class="dsn-effect-scroll dsn-ajax" data-dsn-mousemove="true">

    <div class="preloader">
        <div class="preloader-after"></div>
        <div class="preloader-before"></div>
        <div class="preloader-block">
            <div class="title">CRISTOPH FUCHS <br> <small style="font-size: 12px;">Bauunternehmen</small></div>
            <div class="percent">0</div>
            <div class="loading">loading...</div>
        </div>
        <div class="preloader-bar">
            <div class="preloader-progress"></div>
        </div>
    </div>

    <!-- Nav Bar -->
    <div class="dsn-nav-bar">
        <div class="site-header">
            <div class="extend-container">
                <div class="inner-header">
                    <div class="main-logo">
                        <a href="index.html">
                            <img class="dark-logo" src="<?php echo e(url('storage/'.$setting->logo)); ?>" alt="" />
                            <img class="light-logo" src="<?php echo e(url('storage/'.$setting->logo)); ?>" alt="" />
                        </a>
                    </div>
                </div>
                <nav class=" accent-menu main-navigation">
                    <ul class="extend-container">
                        <li><a href="tel:<?php echo e($setting->phone); ?>"><i class="fas fa-phone"></i> <?php echo e($setting->phone); ?></a></li>
                        <li><a href="tel:<?php echo e($setting->fax); ?>"><i class="fas fa-fax"></i> <?php echo e($setting->fax); ?></a></li>
                        <li><a href="mailto:<?php echo e($setting->email); ?>"><i class="far fa-envelope"></i> <?php echo e($setting->email); ?></a></li>
                    </ul>
                </nav>
            </div>
        </div>
        <div class="header-top header-top-hamburger">
            <div class="header-container">
                <div class="logo main-logo">
                    <a href="index.html">
                        <img class="dark-logo" src="<?php echo e(url('assets/img/logo-dark.png')); ?>" alt="" />
                        <img class="light-logo" src="<?php echo e(url('assets/img/logo.png')); ?>" alt="" />
                    </a>
                </div>

                <div class="menu-icon" data-dsn="parallax" data-dsn-move="5">
                    <div class="icon-m">
                        <i class="menu-icon-close fas fa-times"></i>
                        <span class="menu-icon__line menu-icon__line-left"></span>
                        <span class="menu-icon__line"></span>
                        <span class="menu-icon__line menu-icon__line-right"></span>
                    </div>

                    <div class="text-menu">
                        <div class="text-button">Menu</div>
                        <div class="text-open">Open</div>
                        <div class="text-close">Close</div>
                    </div>
                </div>

                <div class="nav">
                    <div class="inner">
                        <div class="nav__content">

                        </div>
                    </div>
                </div>
                <div class="nav-content">
                    <div class="inner-content">
                        <address class="v-middle">
                            <span>Egypt</span>
                            <span>Damietta</span>
                            <span>01024552406</span>
                        </address>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- End Nav Bar -->

    <main class="main-root">
        <div id="dsn-scrollbar">
            <header>
                <div class="headefr-fexid headefr-fexid-onepage" data-dsn-header="project">
                    <div class="bg has-top-bottom" id="dsn-hero-parallax-img" data-dsn-ajax="img">
                        <div class=" " data-dsn="video" data-overlay="4">
                            <video class="bg-image cover-bg dsn-video" poster="<?php echo e(url('assets/img/map-half1.png')); ?>" autoplay loop
                                muted playsinline>
                                <!-- <source src="http://theme.dsngrid.com/video/videos.mp4" type="video/mp4"> -->
                                Your browser does not support HTML5 video.
                            </video>
                        </div>
                    </div>

                    <div class="project-page__inner">
                        <div class="h-100">
                            <div class="row justify-content-center align-items-center h-100">
                                <div class="project-title" id="dsn-hero-parallax-title">
                                    <div class="sub-text-header">
                                        <h5><?php echo e($page->count); ?> <?php echo $page->count_title; ?></h5>
                                    </div>

                                    <div class="title-text-header">
                                        <span class="title-text-header-inner">
                                            <span><?php echo e($page->slider); ?></span>
                                        </span>
                                    </div>
                                    <!-- <div class="mt-4 link-custom">
                                        <a class="" href="javascript:;"  onclick="smoothScroll('#Location')">Zu den Projekten</a>
                                    </div> -->

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <div class="wrapper">
                <section class="intro-about section-margin" style="background: url(<?php echo e(url('assets/img/map-black1.png')); ?>);margin: 0;background-size: contain;background-position: center center;background-repeat: no-repeat;" id="Location">

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="intro-content-text1" style="height: 800px;">

                                </div>
                            </div>
                        </div>
                </section>
                <section class="intro-about section-margin" style="background: url(<?php echo e(url('assets/img/map-black1.png')); ?>);margin: 0;background-size: contain;background-position: center center;background-repeat: no-repeat;" id="Location">

                        <div class="row">
                            <div class="col-lg-12">
                                <div class="intro-content-text1" style="height: 800px;">
                                    <div class="map-area" >
                                        <div id="googleMap" style="width:100%;height:800px"></div>
                                        <!-- <div id="viewDiv" style="padding: 0;margin: 0;height: 100%;width: 100%;"></div> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                </section>
                <section class="intro-about section-margin">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="intro-content-text text-center">

                                    <h2 data-dsn-grid="move-section"  data-dsn-animate="text" data-dsn-move="-30" data-dsn-duration="100%"
                                        data-dsn-opacity="1.2" data-dsn-responsive="tablet" style="text-align:center;">
                                        <?php echo $page->about_title; ?>

                                    </h2>

                                    <div data-dsn-animate="text"><?php echo $page->about_body; ?></div>

                                    <!-- <h6 data-dsn-animate="text">SALVADOR DALI</h6> -->
                                    <!-- <small data-dsn-animate="text">Digital Artisit</small> -->

                                    <div class="exper" style="margin-top:20px;">
                                        <img src="<?php echo e(url('storage/'.$page->about_signature)); ?>" data-dsn-animate="up" alt="signature" width="200">

                                        <!-- <h4 data-dsn-animate="up">YEARS OF <br> DIGITAL EXPERIENCE</h4> -->
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="background-mask">
                        <div class="background-mask-bg"></div>
                        <div class="img-box">
                            <div class="img-cent" data-dsn-grid="move-up">
                                <div class="img-container">
                                    <img data-dsn-y="30%" src="<?php echo e(url('assets/img/bgg.jpg')); ?>" alt="">
                                </div>
                            </div>
                        </div>
                    </div> -->
                </section>

                <div class="box-seat box-seat-full section-margin">
                    <div class="container-fluid">
                        <div class="inner-img" data-dsn-grid="move-up">
                            <img data-dsn-y="30%" src="<?php echo e(url('storage/'.$page->company_video_image)); ?>" alt="">
                        </div>
                        <div class="pro-text" data-dsn-animate="up">
                            <h3><?php echo $page->company_title; ?></h3>
                            <p><?php echo $page->company_description; ?></p>
                            <div class="link-custom">
                                <a class="image-zoom " href="<?php echo e($page->company_video); ?>" target="_blank" data-dsn="parallax" data-fancybox data-type="iframe" data-preload="false" data-width="800">
                                    <span>Watch Video</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <section class="our-work work-under-header  section-margin" data-dsn-col="3">
                    <!-- <div class="container">
                        <div class="one-title">
                            <div class="title-sub-container">
                                <p class="title-sub">Our Work</p>
                            </div>
                            <h2 class="title-main">Featured Projects</h2>
                        </div>
                    </div> -->
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-9 offset-lg-3">
                                <div class="work-container">
                                    <div class="slick-slider">
                                        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="work-item slick-slide">
                                            <img class="has-top-bottom" src="<?php echo e(url('storage/'.$video->image)); ?>" alt="">
                                            <div class="item-border"></div>
                                            <div class="item-info">
                                                <a href="<?php echo e($video->url); ?>" target="_blank" data-dsn-grid="move-up" class="effect-ajax1" data-fancybox="gallery" data-type="iframe" data-preload="false" data-width="800">

                                                    <!-- <h5 class="cat">Photography</h5>
                                                    <h4>Nile - Kabutha</h4> -->
                                                    <span><span>Watch Video</span></span>
                                                </a>

                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <div class=" box-gallery-vertical section-margin section-padding">
                    <div class="mask-bg"></div>
                    <div class="container">
                        <div class="row align-items-center h-100">
                            <div class="col-lg-6 ">
                                <div class="box-im" data-dsn-grid="move-up">
                                    <img class="has-top-bottom" src="<?php echo e(url('storage/'.$page->intro_video_image)); ?>" alt=""
                                        data-dsn-move="20%">
                                </div>
                            </div>

                            <div class="col-lg-6">


                                <div class="box-info">

                                    <div class="vertical-title" data-dsn-animate="up">
                                        <h2><?php echo $page->intro_title; ?></h2>
                                    </div>

                                    <div data-dsn-animate="up"><?php echo $page->intro_description; ?></div>

                                    <div class="link-custom" data-dsn-animate="up">
                                        <a class="image-zoom effect-ajax1" href="<?php echo e($page->intro_video); ?>" data-dsn="parallax" data-fancybox data-type="iframe" data-preload="false" data-width="800">
                                            <span>Watch Video</span>
                                        </a>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

            </div>

            <footer class="footer">
                <div class="container">


                    <div class="copyright">
                        <div class="text-center">
                            <p><?php echo $setting->copyright_text; ?></p>
                            <div class="copright-text over-hidden">Designed by <a class="link-hover"
                                    data-hover-text="Briskbase Software House" href="https://briskbase.com" target="_blank">BRISKBASE</a>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </main>

    <!-- Wait Loader -->
    <div class="wait-loader">
        <div class="loader-inner">
            <div class="loader-circle">
                <div class="loader-layer"></div>
            </div>
        </div>
    </div>
    <!-- // Wait Loader -->


    <!-- cursor -->
    <div class="cursor">

        <div class="cursor-helper cursor-view">
            <span>VIEW</span>
        </div>

        <div class="cursor-helper cursor-close">
            <span>Close</span>
        </div>

        <div class="cursor-helper cursor-link"></div>
    </div>
    <!-- End cursor -->

    <!-- Optional JavaScript -->
    <script src="<?php echo e(url('assets/js/jquery-3.1.1.min.js')); ?>"></script>
    <script src="https://maps.googleapis.com/maps/api/js?language=en&key=AIzaSyANJ03ykQk3sW_Osu4QRzuygNep9KiubH8"></script>
    <script src="<?php echo e(url('assets/js/plugins.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/dsn-grid.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/custom.js')); ?>"></script>

    <script src="<?php echo e(url('assets.bk/scripts/vlt-plugins.min.js')); ?>"></script>
	<script src="<?php echo e(url('assets.bk/scripts/vlt-helpers.js')); ?>"></script>
	<script src="<?php echo e(url('assets.bk/scripts/vlt-controllers.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.umd.js"></script>
    <script>
      //  JavaScript will go here
      Fancybox.bind("[data-fancybox]", {
  // Your options go here
});
    </script>

    <script>
        var locationPins = <?php echo json_encode($pins); ?>;
        var lat = '<?php echo e($setting->lat); ?>'
        var lng = '<?php echo e($setting->lng); ?>'
    </script>

	<script src="<?php echo e(url('assets.bk/scripts/map.js?v='.time())); ?>"></script>
    <style>
        .gm-style-iw.gm-style-iw-c {
            background: #000;
        }
    </style>
    <script>
        $("#Location").click(function(){
            $(".map-area").removeClass("d-none")
        });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\microsite\resources\views/welcome.blade.php ENDPATH**/ ?>