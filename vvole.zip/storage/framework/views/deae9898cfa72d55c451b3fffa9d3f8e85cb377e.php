<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Add Videos')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(Form::open(array('route' => array('save-video-settings'), 'files' => true))); ?>

                        <div class="row mt-2">
                            <!-- <div class="col-md-12">
                                <div class="alert alert-warning">
                                    Only use video file or video url like vimo, youtube etc
                                </div>
                            </div> -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <?php echo e(Form::label('image', 'Video Placeholder')); ?>

                                    <?php echo e(Form::file('image', ["class" => "form-control"])); ?>

                                </div>
                            </div>
                            <!-- <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('video', 'Video File')); ?>

                                    <?php echo e(Form::file('video', ["class" => "form-control"])); ?>

                                </div>
                            </div> -->
                        </div>

                        <div class="row mt-2">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <?php echo e(Form::label('url', 'Video URL')); ?>

                                    <?php echo e(Form::text('url', old('url'), ["class" => "form-control"])); ?>

                                </div>
                            </div>

                        </div>


                        <div class="row mt-4">
                            <div class="col-md-12">
                                <?php echo e(Form::submit('Save Settings', ["class" => "btn btn-success"])); ?>

                            </div>
                        </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>

            <div class="card">
                <div class="card-header">All Videos</div>
                <div class="card-body">
                    <table class="table table-stripped table-bordered">
                        <thead>
                            <tr>
                                <th>Video URL</th>
                                <th>Image</th>
                                <th>Created At</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($video->url); ?></td>
                                <td><img src="<?php echo e(url('storage/'.$video->image)); ?>" alt="" width="150"></td>
                                <td><?php echo e($video->created_at); ?></td>
                                <td><a href="<?php echo e(route('delete-video', ['id' => $video->id])); ?>" class="btn btn-sm btn-danger">Delete</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u935545640/domains/briskbase.com/public_html/microsite/resources/views/pages/videos.blade.php ENDPATH**/ ?>