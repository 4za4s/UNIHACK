<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Settings')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(Form::open(array('route' => array('save-settings', isset($setting)?$setting->id:''), 'files' => true))); ?>

                        <div class="row mt-2">
                            <div class="col-md-12">
                                <h4>Map Center</h4>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('lat', 'Latitude')); ?>

                                    <?php echo e(Form::text('lat', (isset($setting)?$setting->lat:old('lat')), ["class" => "form-control", "id" => "lat"])); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('lng', 'Longitude')); ?>

                                    <?php echo e(Form::text('lng', (isset($setting)?$setting->lng:old('lng')), ["class" => "form-control", "id" => "lng"])); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-6">
                            <?php if(!is_null($setting) && isset($setting->logo)): ?>
                                    <img src="<?php echo e(url('storage/'.$setting->logo)); ?>" alt="" width="40">
                                <?php endif; ?>
                                <div class="form-group">
                                    <?php echo e(Form::label('logo', 'Website Logo')); ?>

                                    <?php echo e(Form::file('logo', ["class" => "form-control"])); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <?php if(!is_null($setting) && isset($setting->favicon)): ?>
                                    <img src="<?php echo e(url('storage/'.$setting->favicon)); ?>" alt="" width="40">
                                <?php endif; ?>
                                <div class="form-group">
                                    <?php echo e(Form::label('favicon', 'Favicon')); ?>

                                    <?php echo e(Form::file('favicon', ["class" => "form-control"])); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-6">
                                <?php if(!is_null($setting) && isset($setting->slider_logo)): ?>
                                    <img src="<?php echo e(url('storage/'.$setting->slider_logo)); ?>" alt="" width="40">
                                <?php endif; ?>
                                <div class="form-group">
                                    <?php echo e(Form::label('slider_logo', 'Slider Logo')); ?>

                                    <?php echo e(Form::file('slider_logo', ["class" => "form-control"])); ?>

                                </div>
                            </div>
                            <div class="col-md-6">

                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('email', 'E-Mail Address')); ?>

                                    <?php echo e(Form::text('email', (isset($setting)?$setting->email:old('email')), ["class" => "form-control"])); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('phone', 'Phone Number')); ?>

                                    <?php echo e(Form::text('phone', (isset($setting)?$setting->phone:old('phone')), ["class" => "form-control"])); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('fax', 'Fax Number')); ?>

                                    <?php echo e(Form::text('fax', (isset($setting)?$setting->fax:old('fax')), ["class" => "form-control"])); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('facebook_link', 'Facebook Link')); ?>

                                    <?php echo e(Form::text('facebook_link', (isset($setting)?$setting->facebook_link:old('facebook_link')), ["class" => "form-control"])); ?>

                                </div>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('twitter_link', 'Twitter Link')); ?>

                                    <?php echo e(Form::text('twitter_link', (isset($setting)?$setting->twitter_link:old('twitter_link')), ["class" => "form-control"])); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('linkedin_link', 'Linkedin Link')); ?>

                                    <?php echo e(Form::text('linkedin_link', (isset($setting)?$setting->linkedin_link:old('linkedin_link')), ["class" => "form-control"])); ?>

                                </div>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('youtube_link', 'Youtube Link')); ?>

                                    <?php echo e(Form::text('youtube_link', (isset($setting)?$setting->youtube_link:old('youtube_link')), ["class" => "form-control"])); ?>

                                </div>
                            </div>
                            <div class="col-md-12 mt-3">
                                <div class="form-group">
                                    <?php echo e(Form::label('copyright_text', 'Copyright Text')); ?>

                                    <?php echo e(Form::textarea('copyright_text', (isset($setting)?$setting->copyright_text:old('copyright_text')), ["class" => "form-control", "rows"=> 3])); ?>

                                </div>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('meta_title', 'Meta Title')); ?>

                                    <?php echo e(Form::text('meta_title', (isset($setting)?$setting->meta_title:old('meta_title')), ["class" => "form-control"])); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <?php echo e(Form::label('meta_keywords', 'Meta Keywords')); ?>

                                    <?php echo e(Form::text('meta_keywords', (isset($setting)?$setting->meta_keywords:old('meta_keywords')), ["class" => "form-control"])); ?>

                                </div>
                            </div>

                        </div>
                        <div class="row mt-2">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <?php echo e(Form::label('meta_description', 'Meta Description')); ?>

                                    <?php echo e(Form::textarea('meta_description', (isset($setting)?$setting->meta_description:old('meta_description')), ["class" => "form-control", "rows"=> 3])); ?>

                                </div>
                            </div>
                        </div>


                        <div class="row mt-4">
                            <div class="col-md-12">
                                <?php echo e(Form::submit('Save Settings', ["class" => "btn btn-success"])); ?>

                            </div>
                        </div>
                    <?php echo e(Form::close()); ?>



                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\microsite\resources\views/pages/settings.blade.php ENDPATH**/ ?>